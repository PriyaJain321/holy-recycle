from django.db import models
from multiselectfield import MultiSelectField
# Create your models here.


# ...


type_waste = ((1, 'Idols'),
               (2, 'Posters'),
               (3, 'Flowers'),
               (4, 'Pots'),
               (5, 'Others'))


  # .....

   
    



class person(models.Model):

         username = models.CharField(max_length=100)
         email = models.EmailField(max_length=100)
         adderess = models.TextField(max_length=500)
         date = models.DateField(auto_now=True)
         ph_no = models.IntegerField(max_length=10)
         type_waste = MultiSelectField(choices=type_waste,
                                 max_choices=5)