from django.shortcuts import render
from django.contrib.auth.models import User, auth
# Create your views here.



def register(request):  
     if request.method =='POST':
         username = request.POST['Name']
         email = request.POST['Email']
         adderess = request.POST['Address for Shipping']
         date = request.POST['Date of Shipping']
         ph_no = request.POST['Phone Number']
            
         user = User.objects.create_user(username=username, email=email, adderess=adderess, date=date, ph_no=ph_no)
         user.save()
         print('user created')

     else:
         return render(request,'register.html')